package com.mtechviral.musicfinder;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.AudioManager;
import android.media.MediaMetadataRetriever;
import android.media.MediaPlayer;
import android.media.session.MediaSession;
import android.media.session.PlaybackState;
import android.os.Binder;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.support.annotation.Nullable;
import android.support.v4.app.NotificationCompat;
import android.util.Log;
import android.widget.RemoteViews;

import java.io.IOException;
import java.util.Map;


public class PlayerService extends Service {

    public final static String PLAY_BROADCAST = "org.procodingtools.Player.Play",
            SEEK_BROADCAST = "org.procodingtools.musiks.Player.Seek",
            PAUSE_BROADCAST = "org.procodingtools.musiks.Player.Pause",
            STOP_BROADCAST = "org.procodingtools.musiks.Player.Stop",
            SET_EQUALIZER_ENABLED = "org.procodingtools.musiks.Player.eq.enabled",
            SET_EQUALIZER_BAND = "org.procodingtools.musiks.Player.eq.band",
            SET_EQUALIZER_PRESET = "org.procodingtools.musiks.Player.eq.preset",
            GET_EQUALIZER_ENABLED = "org.procodingtools.musiks.Player.eq.enabled",
            GET_EQUALIZER_BANDS = "org.procodingtools.musiks.Player.eq.band",
            GET_EQUALIZER_PRESETS = "org.procodingtools.musiks.Player.eq.preset",
            GET_EQUALIZER_STATUS = "org.pprocodingtools.musiks.Player.eq.get",
            GET_CURRENT_SONG = "audio.currentSong",
            ON_START = "audio.onStart",
            ON_PAUSE_BROADCAST = "org.procodingtools.Player.Onpause",
            ON_STOP = "audio.onComplete",
            ON_ERROR = "audio.onError",
            ON_DURATION = "audio.onDuration",
            ON_CURRENT_SONG = "audio.onCurrentSong",
            ON_SERVICE_STARTED = "service.onStart",
            ON_CURRENT_POSITION = "audio.onCurrentPosition",
            ON_PLAY_PAUSE_NOTIF_CLICK = "audio.onPlayPauseNotifClick",
            ON_CLOSE_NOTIF = "org.procodinftools.closenotif";

    private static final int NOTIF_ID = 22356;


    private MediaPlayer mediaPlayer;
    private final PlayerServiceBinder binder = new PlayerServiceBinder();
    public static final String CHANNEL_ID = "MusiksForegroundServiceChannel";
    private String songUrl = "";
    private MediaMetadataRetriever mediaMetadataRetriever = new MediaMetadataRetriever();
    private NotificationManager notificationManager;

    private final Handler handler = new Handler();
    private RemoteViews notificationLayout;

    private AndroidEqualizer equalizer;


    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return binder;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {



        IntentFilter playerBroadcastFilter = new IntentFilter();
        playerBroadcastFilter.addAction(PLAY_BROADCAST);
        playerBroadcastFilter.addAction(PAUSE_BROADCAST);
        playerBroadcastFilter.addAction(STOP_BROADCAST);
        playerBroadcastFilter.addAction(SEEK_BROADCAST);
        playerBroadcastFilter.addAction(GET_CURRENT_SONG);
        playerBroadcastFilter.addAction(ON_CLOSE_NOTIF);
        playerBroadcastFilter.addAction(ON_PLAY_PAUSE_NOTIF_CLICK);
        playerBroadcastFilter.addAction(Intent.ACTION_HEADSET_PLUG);
        playerBroadcastFilter.addAction(SET_EQUALIZER_BAND);
        playerBroadcastFilter.addAction(SET_EQUALIZER_ENABLED);
        playerBroadcastFilter.addAction(SET_EQUALIZER_PRESET);
        playerBroadcastFilter.addAction(GET_EQUALIZER_STATUS);

        try {
            registerReceiver(receiver, playerBroadcastFilter);
        } catch (Exception ignored) {
        }


        sendBroadcast(new Intent(ON_SERVICE_STARTED));

        return START_STICKY;
    }

    private Notification createNotif() {
        Intent notificationIntent = new Intent("org.procodingtools.Musiks");
        PendingIntent pendingIntent = PendingIntent.getActivity(this,
                0, notificationIntent, 0);


        Notification notification;
        notification = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setCustomBigContentView(notificationLayout)
                .setSmallIcon(R.drawable.ic_launcher)
                .setOngoing(true)
                .setContentIntent(pendingIntent)
                .build();

        return notification;
    }


    @Override
    public void onDestroy() {
        Log.e("onDestroy", "Called");
        notificationManager.cancel(NOTIF_ID);
        if (mediaPlayer != null) {
            if (mediaPlayer.isPlaying())
                mediaPlayer.stop();
            mediaPlayer.reset();
            equalizer.dispose();
            mediaPlayer.release();
            mediaPlayer = null;
        }
        unregisterReceiver(receiver);
        super.onDestroy();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel serviceChannel = new NotificationChannel(
                    CHANNEL_ID,
                    "Foreground Service Channel",
                    NotificationManager.IMPORTANCE_DEFAULT
            );

            NotificationManager manager = getSystemService(NotificationManager.class);
            manager.createNotificationChannel(serviceChannel);
        }
    }


    public void play(String url) {
        this.songUrl = url;
        if (mediaPlayer == null) {
            mediaPlayer = new MediaPlayer();
            mediaPlayer.setAudioStreamType(AudioManager.STREAM_MUSIC);
            try {
                mediaPlayer.setDataSource(url);
            } catch (IOException e) {
                e.printStackTrace();
                Log.d("AUDIO", "invalid DataSource");
            }

            mediaPlayer.prepareAsync();
        } else {
            sendBroadcast(new Intent(ON_DURATION).putExtra("val", mediaPlayer.getDuration()));
            mediaPlayer.start();
            sendBroadcast(new Intent(ON_START).putExtra("val", true));

        }

        mediaPlayer.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
            @Override
            public void onPrepared(MediaPlayer mp) {
                sendBroadcast(new Intent(ON_DURATION).putExtra("val", mediaPlayer.getDuration()));

                mediaPlayer.start();
                sendBroadcast(new Intent(ON_START).putExtra("val", true));
            }
        });

        mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mp) {
                stop();
                sendBroadcast(new Intent(ON_STOP).putExtra("val", true));

            }
        });

        mediaPlayer.setOnErrorListener(new MediaPlayer.OnErrorListener() {
            @Override
            public boolean onError(MediaPlayer mp, int what, int extra) {
                sendBroadcast(new Intent(ON_ERROR)
                        .putExtra("val", String.format("{\"what\":%d,\"extra\":%d}", what, extra))
                        .putExtra("what", what).putExtra("extra", extra));

                return true;

            }
        });

        try {
            handler.post(sendData);
        } catch (Exception ignored) {
        }

        mediaMetadataRetriever.setDataSource(songUrl);
        String title = "Musiks";
        String album = "Musiks";
        try {
            title = mediaMetadataRetriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE);
        } catch (Exception ignored) {
        }
        try {
            album = mediaMetadataRetriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST);
        } catch (Exception ignored) {
        }
        notificationLayout.setTextViewText(R.id.title_tv, title);
        notificationLayout.setTextViewText(R.id.sub_title_tv, album);
        notificationLayout.setImageViewResource(R.id.play_pause_iv, R.drawable.pause_purple);

        try {
            byte[] art = mediaMetadataRetriever.getEmbeddedPicture();
            Bitmap img = BitmapFactory.decodeByteArray(art, 0, art.length);
            notificationLayout.setImageViewBitmap(R.id.img, img);
        } catch (Exception e) {
            notificationLayout.setImageViewResource(R.id.img, R.drawable.ic_launcher);
        }
        notificationManager.notify(NOTIF_ID, createNotif());

        equalizer = new AndroidEqualizer(mediaPlayer.getAudioSessionId());

    }

    public void stop() {
        handler.removeCallbacks(sendData);
        songUrl = "";
        if (mediaPlayer != null) {
            mediaPlayer.stop();
            mediaPlayer.release();
            mediaPlayer = null;
            equalizer.dispose();
            equalizer = null;
            notificationLayout.setImageViewResource(R.id.play_pause_iv, R.drawable.play_purple);
            notificationManager.notify(NOTIF_ID, createNotif());
        }
    }

    public void pause() {
        mediaPlayer.pause();
        handler.removeCallbacks(sendData);
        notificationLayout.setImageViewResource(R.id.play_pause_iv, R.drawable.play_purple);
        notificationManager.notify(NOTIF_ID, createNotif());
    }

    public void seek(double position) {
        mediaPlayer.seekTo((int) (position * 1000));
    }


    @Override
    public void onCreate() {
        super.onCreate();

        //parentContext = MusicFinderPlugin.registrar.context().clone();

        initNotif();

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            MediaSession.Callback callback = new MediaSession.Callback() {
                @Override
                public void onPlay() {
                    super.onPlay();
                    if (!songUrl.equals(""))
                        play(songUrl);
                }

                @Override
                public void onPause() {
                    super.onPause();
                    pause();
                }
            };

            MediaSession mediaSession = new MediaSession(this, "MUSIKS_MEDIA_SESSION");
            mediaSession.setFlags(
                    MediaSession.FLAG_HANDLES_MEDIA_BUTTONS |
                            MediaSession.FLAG_HANDLES_TRANSPORT_CONTROLS);
            mediaSession.setCallback(callback);

            mediaSession.setPlaybackState(
                    new PlaybackState.Builder()
                            .setActions(PlaybackState.ACTION_PLAY |
                                    PlaybackState.ACTION_PAUSE |
                                    PlaybackState.ACTION_PLAY_PAUSE)
                            .setState(PlaybackState.STATE_PLAYING,
                                    0, // playback position in milliseconds
                                    1.0f).build()); // playback speed

// Call this when you start playback after receiving audio focus
            mediaSession.setActive(true);
        }
        }

    private void initNotif() {
        createNotificationChannel();

        notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

        notificationLayout = new RemoteViews(getPackageName(), R.layout.notification_content);


        notificationLayout.setOnClickPendingIntent(R.id.play_pause_iv, getPendingSelfIntent(this, ON_PLAY_PAUSE_NOTIF_CLICK));
        notificationLayout.setOnClickPendingIntent(R.id.close_iv, getPendingSelfIntent(this, ON_CLOSE_NOTIF));

        startForeground(NOTIF_ID, createNotif());
    }


    protected PendingIntent getPendingSelfIntent(Context context, String action) {
        Intent intent = new Intent(action);
        return PendingIntent.getBroadcast(context, 0, intent, 0);
    }


    private final Runnable sendData = new Runnable() {
        public void run() {
            try {
                if (!mediaPlayer.isPlaying()) {
                    handler.removeCallbacks(sendData);
                }
                int time = mediaPlayer.getCurrentPosition();

                sendBroadcast(new Intent(ON_CURRENT_POSITION)
                        .putExtra("val", time));

                handler.postDelayed(this, 200);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    };

    private BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            if (intent.getAction().equals(PLAY_BROADCAST)) {
                play(intent.getStringExtra("url"));
            } else if (intent.getAction().equals(PAUSE_BROADCAST)) {
                if (mediaPlayer != null)
                    pause();
            } else if (intent.getAction().equals(STOP_BROADCAST)) {
                stop();
            } else if (intent.getAction().equals(SEEK_BROADCAST)) {
                seek(intent.getDoubleExtra("val", 0.0));
            } else if (intent.getAction().equals(GET_CURRENT_SONG)) {
                String url = "";
                if (mediaPlayer != null) {
                    url = songUrl;
                }
                sendBroadcast(new Intent(ON_CURRENT_SONG).putExtra("val", url));
            } else if (intent.getAction().equals(Intent.ACTION_HEADSET_PLUG)) {
                if (!songUrl.equals("")) {
                    if (intent.getIntExtra("state", 0) == 0) {
                        pause();
                    } else {
                        play(songUrl);
                    }
                }
            } else if (intent.getAction().equals(ON_PLAY_PAUSE_NOTIF_CLICK)) {
                if (mediaPlayer.isPlaying())
                    pause();
                else
                    play(songUrl);
            } else if (intent.getAction().equals(ON_CLOSE_NOTIF)) {
                sendBroadcast(new Intent("org.procodingtools.musiks.finish"));
                stopSelf();
            } else if (intent.getAction().equals(SET_EQUALIZER_BAND)) {
                Map<Integer, Integer> bands = (Map<Integer, Integer>) intent.getSerializableExtra("bands");
                for (int band : bands.keySet()) {
                    equalizer.setBand(band, bands.get(band));
                }
            } else if (intent.getAction().equals(SET_EQUALIZER_PRESET)) {
                equalizer.setPreset(intent.getExtras().getInt("preset"));
            } else if (intent.getAction().equals(SET_EQUALIZER_ENABLED)) {
                equalizer.enable(intent.getExtras().getBoolean("enabled"));
            }else if (intent.getAction().equals(GET_EQUALIZER_STATUS)){
                sendBroadcast(new Intent(GET_EQUALIZER_BANDS).putExtra("bands", equalizer.getBands()));
                sendBroadcast(new Intent(GET_EQUALIZER_PRESETS).putExtra("presets", equalizer.getPresets()));
                sendBroadcast(new Intent(GET_EQUALIZER_ENABLED).putExtra("enabled", equalizer.isEnabled()));

            }
        }
    };


    public class PlayerServiceBinder extends Binder {
        PlayerService getService() {
            return PlayerService.this;
        }
    }

}