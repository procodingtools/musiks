package com.mtechviral.musicfinder;

import android.media.audiofx.Equalizer;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AndroidEqualizer {

    private int mpSessionId;
    private Equalizer equalizer;
    private short _bands, _presets;
    private HashMap<Integer, Integer> bands;
    private HashMap<Integer, String>  presets;

    public AndroidEqualizer(int mediaPlayerSessionId){
        mpSessionId = mediaPlayerSessionId;

        equalizer = new Equalizer(0, mpSessionId);

        _bands = equalizer.getNumberOfBands();
        _presets = equalizer.getNumberOfPresets();

        bands = new HashMap<>();
        presets = new HashMap<>();
        for (short i = 0; i < _bands; i++){
            bands.put((int)i, (int)equalizer.getBandLevel(i));
        }

        for (short i = 0; i < _presets; i++){
            presets.put((int)i, equalizer.getPresetName(i));
        }
    }

    public HashMap<Integer, Integer> getBands() {
        return bands;
    }

    public HashMap<Integer, String> getPresets() {
        return presets;
    }

    public void setPreset(int preset){
        equalizer.usePreset((short)preset);
    }

    public void setBand(int band, int level){
        equalizer.setBandLevel((short)band, (short)level);
    }

    public void dispose(){
        equalizer.release();
    }

    public boolean isEnabled(){
        return equalizer.getEnabled();
    }

    public void enable(boolean status){
        equalizer.setEnabled(status);
    }


}
